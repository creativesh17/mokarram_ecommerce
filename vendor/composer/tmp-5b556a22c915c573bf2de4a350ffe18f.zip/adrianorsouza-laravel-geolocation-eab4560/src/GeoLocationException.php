<?php

namespace Adrianorosa\GeoLocation;

/**
 * Class GeoLocationException.
 *
 * @author Adriano Rosa <https://adrianorosa.com>
 * @date 2019-08-13 16:00
 *
 * @package Adrianorosa\GeoLocation
 */
class GeoLocationException extends \Exception
{
}
